# Project Instructions

Follow the instructions here: https://vuxcode.netlify.app/new/we1/lessons/major-project-brief/

The aim of the project is to show how you have developed your website, the steps you have taken and the problems you have solved!

REMEMBER TO "COMMIT" YOUR CHANGES REGULARLY TO SHOW HOW YOU HAVE BUILT THIS PROJECT!

# Project Notes

> You can use this section of the file to keep notes about your project as you work on it

# Project Summary

> Before the final submission date you should include a "PROJECT SUMMARY" in this section here.